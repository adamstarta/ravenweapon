<?php declare(strict_types=1);

namespace RavenTheme;

use Shopware\Core\Framework\Plugin;
use Shopware\Storefront\Framework\ThemeInterface;

class RavenTheme extends Plugin implements ThemeInterface
{
}